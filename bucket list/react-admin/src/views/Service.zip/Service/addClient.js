/* eslint-disable jsx-a11y/label-has-associated-control */
import React, { useState } from 'react';
import { Dialog, DialogTitle, DialogContent, DialogActions, Button, TextField, Stack, Grid, IconButton, Typography } from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import { useFormik } from 'formik';
import * as Yup from 'yup';

const AddCategory = ({ open, close }) => {
    const [subcategories, setSubcategories] = useState([]); // State for subcategories
    const [selectedCategory, setSelectedCategory] = useState(''); // State for selected category

    // Form validation schema using Yup
    const validationSchema = Yup.object({
        category: Yup.string().required('Category is required'),
        subcategory: Yup.string().max(50, 'Subcategory should be less than 50 characters')
    });

    const initialValues = {
        category: '', // Category starts as an empty string
        subcategory: '' // Subcategory input is also empty at first
    };

    const formik = useFormik({
        initialValues,
        validationSchema,
        onSubmit: (values) => {
            console.log({
                category: values.category,
                subcategories // Pass the subcategories state directly
            }); // Handle form submission logic
        }
    });

    const handleAddSubcategory = () => {
        const subcategory = formik.values.subcategory.trim(); // Trim any leading/trailing spaces
        if (subcategory && !subcategories.includes(subcategory)) {
            setSubcategories([...subcategories, subcategory]);
            formik.setFieldValue('subcategory', ''); // Reset subcategory field after adding
        }
    };

    const handleRemoveSubcategory = (subcategoryToRemove) => {
        setSubcategories(subcategories.filter((sub) => sub !== subcategoryToRemove));
    };

    return (
        <Dialog open={open} onClose={() => close(false)} fullWidth maxWidth="md">
            <form onSubmit={formik.handleSubmit}>
                <DialogTitle>
                    <Grid container spacing={3} alignItems="center">
                        <Grid item xs={10}>
                            Add Service
                        </Grid>
                        <Grid item xs={2}>
                            <IconButton
                                color="inherit"
                                onClick={() => close(false)}
                                aria-label="close"
                                sx={{ position: 'absolute', right: 8, top: 8 }}
                            >
                                <CloseIcon />
                            </IconButton>
                        </Grid>
                    </Grid>
                </DialogTitle>

                <DialogContent>
                    <Grid container spacing={2} direction="column">
                        {/* Category Field */}
                        <Grid item xs={12} sm={6} sx={{ marginTop: '5px' }}>
                            <TextField
                                id="category"
                                name="category"
                                label="Category"
                                value={formik.values.category}
                                onChange={formik.handleChange}
                                onBlur={formik.handleBlur}
                                error={formik.touched.category && Boolean(formik.errors.category)}
                                helperText={formik.touched.category && formik.errors.category}
                                fullWidth
                            />
                        </Grid>

                        {/* Subcategory Field */}
                        <Grid item xs={12} sm={6}>
                            <TextField
                                id="subcategory"
                                name="subcategory"
                                label="Add Subcategory"
                                value={formik.values.subcategory}
                                onChange={formik.handleChange}
                                onBlur={formik.handleBlur}
                                error={formik.touched.subcategory && Boolean(formik.errors.subcategory)}
                                helperText={formik.touched.subcategory && formik.errors.subcategory}
                                fullWidth
                            />
                            <Button variant="outlined" color="secondary" onClick={handleAddSubcategory} sx={{ marginTop: '8px' }}>
                                Add Subcategory
                            </Button>
                            <Stack direction="row" spacing={1} sx={{ marginTop: '8px', flexWrap: 'wrap' }}>
                                {subcategories.map((sub, index) => (
                                    <Grid
                                        item
                                        key={index}
                                        sx={{
                                            display: 'flex',
                                            alignItems: 'center',
                                            backgroundColor: 'white',
                                            padding: '0.5em',
                                            borderRadius: '4px'
                                        }}
                                    >
                                        <Typography
                                            variant="body2"
                                            sx={{
                                                whiteSpace: 'nowrap',
                                                overflow: 'hidden',
                                                textOverflow: 'ellipsis',
                                                display: 'inline-block' // Ensure the width adjusts to content
                                            }}
                                        >
                                            {sub}
                                        </Typography>
                                        <IconButton
                                            onClick={() => handleRemoveSubcategory(sub)}
                                            color="error"
                                            aria-label="remove subcategory"
                                        >
                                            <CloseIcon />
                                        </IconButton>
                                    </Grid>
                                ))}
                            </Stack>
                        </Grid>
                    </Grid>
                </DialogContent>

                <DialogActions>
                    <Button onClick={() => close(false)} color="primary">
                        Cancel
                    </Button>
                    <Button type="submit" variant="contained" color="primary">
                        Save
                    </Button>
                </DialogActions>
            </form>
        </Dialog>
    );
};

export default AddCategory;
